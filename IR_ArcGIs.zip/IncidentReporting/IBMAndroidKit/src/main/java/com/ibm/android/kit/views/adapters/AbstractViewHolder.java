package com.ibm.android.kit.views.adapters;


public abstract class AbstractViewHolder {

	public String id;
}
