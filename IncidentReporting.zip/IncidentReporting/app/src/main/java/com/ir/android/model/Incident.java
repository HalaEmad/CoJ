package com.ir.android.model;

import com.google.android.gms.maps.model.LatLng;

/**
 * Created by emanhassan on 6/10/16.
 */
public class Incident {

    public double latitude;
    public double longitude;
    public String info;

    public Incident(double latitude, double longitude, String info) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.info = info;
    }
}

