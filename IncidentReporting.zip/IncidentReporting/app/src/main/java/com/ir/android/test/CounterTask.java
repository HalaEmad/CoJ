package com.ir.android.test;

import android.content.Context;
import android.os.SystemClock;

import com.ibm.android.kit.models.Result;
import com.ibm.android.kit.tasks.ITask;
import com.ibm.android.kit.tasks.Task;

/**
 * Created by emanhassan on 6/9/16.
 */
public class CounterTask extends Task
{
    public CounterTask(ITask listener, Context context) {
        super(listener, context);
    }

    @Override
    protected Result onTaskWork() {

        for(int i=0; i<1000; i++)
        {
            if(isCancelled()) {
                return new Result(0);
            }

            updateView(i);
            SystemClock.sleep(1000);
        }

        return new Result(0);
    }
}
