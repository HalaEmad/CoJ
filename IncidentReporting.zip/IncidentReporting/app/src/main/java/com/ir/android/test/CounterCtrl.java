package com.ir.android.test;

import android.content.Intent;

import com.ibm.android.kit.controllers.Controller;
import com.ibm.android.kit.models.Result;
import com.ibm.android.kit.models.ViewModel;
import com.ibm.android.kit.tasks.Task;

/**
 * Created by emanhassan on 6/9/16.
 */
public class CounterCtrl extends Controller implements CounterViewListener{

    private int count;
    boolean isStarted;
    private CounterTask task;

    @Override
    public ViewModel initViewModel() {
        return new CounterViewModel(count, isStarted);
    }

    @Override
    public void init(Intent intent) {
        super.init(intent);
        updateViewModel();
    }

    @Override
    public void startStop() {

        if(!isStarted) {
            task = new CounterTask(this, getContext());
            task.execute();
        } else
        {
            task.cancel(false);
        }

        isStarted = !isStarted;

    }

    private void updateViewModel() {

        ((CounterViewModel) viewModel).setCounter(""+count);
        ((CounterViewModel) viewModel).setBtnText(isStarted?"Stop":"Start");
    }

    @Override
    public void onTaskStarted(Task task) {
        super.onTaskStarted(task);
    }

    @Override
    public void onTaskFinished(Task task, Result result) {
        super.onTaskFinished(task, result);

        isStarted = false;
        updateViewModel();
    }

    @Override
    public void onTaskCanceled(Task task) {
        super.onTaskCanceled(task);

        isStarted = false;
        updateViewModel();
    }

    @Override
    public void onTaskProgress(Task task, int progress) {
        super.onTaskProgress(task, progress);

        count = progress;
        updateViewModel();
    }
}
