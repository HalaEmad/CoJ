package com.ir.android.test;

/**
 * Created by emanhassan on 6/9/16.
 */
public interface CounterViewListener {

    public void startStop();

}
