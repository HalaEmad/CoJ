package com.ir.android.test;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.ibm.android.kit.controllers.Controller;
import com.ibm.android.kit.models.ViewModel;
import com.ibm.android.kit.views.activities.Activity;
import com.ir.android.R;

/**
 * Created by emanhassan on 6/9/16.
 */
public class CounterScreen extends Activity {

    private TextView counterText;
    private Button startStopBtn;

    @Override
    protected Controller getController() {
        return new CounterCtrl();
    }

    @Override
    protected String getControllerTag() {
        return "counter.ctrl";
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_counter;
    }

    @Override
    protected void initViews() {

        counterText = (TextView) findViewById(R.id.counter_text);
        startStopBtn = (Button) findViewById(R.id.start_stop_btn);
        startStopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((CounterViewListener)controller).startStop();
            }
        });
    }

    @Override
    protected void bindViews(ViewModel viewInfo) {

        counterText.setText(((CounterViewModel)viewInfo).getCounter());
        startStopBtn.setText(((CounterViewModel)viewInfo).getBtnText());
    }
}
