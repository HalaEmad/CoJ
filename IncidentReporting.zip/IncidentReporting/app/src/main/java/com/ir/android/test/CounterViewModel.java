package com.ir.android.test;

import com.ibm.android.kit.models.ViewModel;

/**
 * Created by emanhassan on 6/9/16.
 */
public class CounterViewModel extends ViewModel {

    private String counter;
    private String btnText;

    public CounterViewModel(int counter, boolean isStarted) {
        this.counter = ""+counter;
        btnText = isStarted?"Stop":"Start";
    }

    public String getCounter() {
        return counter;
    }

    public void setCounter(String counter) {
        this.counter = counter;
        setModelChanged();
    }

    public String getBtnText() {
        return btnText;
    }

    public void setBtnText(String btnText) {
        this.btnText = btnText;
        setModelChanged();
    }
}
